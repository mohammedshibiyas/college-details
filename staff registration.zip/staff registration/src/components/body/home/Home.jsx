import React from 'react'
import './Home.css'
import { Link } from 'react-router-dom'



const Home = () => {
  return (
    <div>
        <h1>hello</h1>
     
     <div className="admin">
     <Link to='/login'> <button>ADMIN</button></Link>
     </div>
     <div className="admin">
     <Link> <button>STAFF</button></Link>
     </div>
     <div className="admin">
     <Link> <button>STUDENT</button></Link>
     </div>
    </div>
  )
} 

export default Home
