import React from 'react'
import './Login.css'
import { Link } from 'react-router-dom'

const Login = () => {
  return (
    <div>
      <div className="loginpage">
      <div className="user">
       <input type="text" placeholder='Username' />
       </div>
       <div className="user">
       <input type="text" placeholder='password' />

       </div>
      <Link className='login'><button id='login-btn'>LOGIN</button></Link>
      </div>
    </div>
  )
}

export default Login
