import { useState } from 'react'

import './App.css'
import Home from './components/body/home/Home'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Login from './components/body/login/Login'

function App() {
 

  return (
    <>
     <BrowserRouter>
     <Routes>
        <Route path='/' Component={Home}/>
        <Route path='/login' Component={Login}/>
     </Routes>
     </BrowserRouter>
    </>
  )
}

export default App
